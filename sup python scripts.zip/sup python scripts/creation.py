import sqlite3

conn = sqlite3.connect('TimmyTutorFinal.db')

c = conn.cursor()


c.execute('''CREATE TABLE Badges(
    	badgeID INTEGER 
	PRIMARY KEY,
	studentID INTEGER
);''')

c.execute('''CREATE TABLE BadgeColor(
	badgeColorID INTEGER
	PRIMARY KEY,
	badgeID INTEGER,
	badgeColor TEXT
);''')

c.execute('''CREATE TABLE Students(
	studentID INTEGER 
	PRIMARY KEY,
	firstname TEXT,
	lastname TEXT,
	dob DATE
);''')

c.execute('''CREATE TABLE grouptable(
	groupID INTEGER
	PRIMARY KEY,
	studentID INTEGER
);''')

c.execute('''CREATE TABLE Teacher(
	teacherID INTEGER 
	PRIMARY KEY,
	firstname TEXT,
	lastname TEXT
);''')

c.execute('''CREATE TABLE Attendance(
	attendance INTEGER
	PRIMARY KEY,
	meetingID INTEGER,
	studentID INTEGER
);''')

c.execute('''CREATE TABLE Meeting(
	meetingID INTEGER
	PRIMARY KEY,
	teacherID INTEGER,
	timedate DATE,
	place TEXT,
	topic TEXT
);''')

c.execute('''CREATE TABLE WeekendIntensives(
	weekendIntensivesID INTEGER
	PRIMARY KEY,
	studentID INTEGER,
	week1 BOOLEAN DEFAULT FALSE,
	week2 BOOLEAN DEFAULT FALSE,
	week3 BOOLEAN DEFAULT FALSE,
	weekN BOOLEAN DEFAULT FALSE
);''')

c.execute('''CREATE TABLE WeeklyMeetings(
	weeklyMeetingID INTEGER
	PRIMARY KEY,
	studentID INTEGER,
	week1 BOOLEAN DEFAULT FALSE,
	week2 BOOLEAN DEFAULT FALSE,
	week3 BOOLEAN DEFAULT FALSE,
	weekN BOOLEAN DEFAULT FALSE
);''')

c.execute('''CREATE TABLE Leaderboard(
	leaderID INTEGER
	PRIMARY KEY,
	studentID INTEGER 
	rank INTEGER,
	score INTEGER
);''')

c.execute('''CREATE TABLE Test(
	testID INTEGER 
	PRIMARY KEY,
	testName Text,
	studentID INTEGER,
	badgeID INTEGER,
	completionStatus BOOLEAN
);''')

c.execute('''CREATE TABLE Topic(
	topicID INTEGER 
	PRIMARY KEY,
	studentID INTEGER,
	topicName TEXT,
	testID INTEGER,
	completionStatus BOOLEAN
);''')

c.execute('''CREATE TABLE Part(
	partID INTEGER 
	PRIMARY KEY,
	partName TEXT,
	topicID INTEGER,
	completionStatus BOOLEAN
);''')
conn.commit()
conn.close()
