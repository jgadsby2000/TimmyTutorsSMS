import sqlite3

conn = sqlite3.connect('TimmyTutorFinal.db')

c = conn.cursor()


c.execute('''INSERT INTO WeekendIntensives ( studentID, week1, week2, week3, weekN) VALUES ( 2, TRUE, TRUE, TRUE, TRUE);''')

c.execute('''INSERT INTO WeeklyMeetings ( studentID, week1, week2, week3, weekN) VALUES ( 2, TRUE, TRUE, TRUE, TRUE);''')

c.execute('''INSERT INTO Students (firstname, lastname, dob) VALUES ('Jack', 'Jack', 2000-04-11);''')

c.execute('''INSERT INTO grouptable (studentid) VALUES (1);''')

c.execute('''INSERT INTO Topic (studentID, topicName, testid, completionstatus ) VALUES (2, 'beer', 2, TRUE);''')

c.execute('''INSERT INTO Test (testname, studentid, badgeid, completionstatus) VALUES ('BEERTEST', 2, 2, TRUE);''')

c.execute('''INSERT INTO Teacher (firstname, lastname) VALUES ('Mrs', 'Mister');''')

c.execute('''INSERT INTO Part (partname, topicid, completionstatus) VALUES ('BeerPart', 2, TRUE);''')

c.execute('''INSERT INTO Meeting (teacherid, timedate, place, topic) VALUES (2, 2019-11-11, 'Bar', 'Beer');''')

c.execute('''INSERT INTO Badges (studentid) VALUES (2);''')


conn.commit()
conn.close()
