import sqlite3

conn = sqlite3.connect('TimmyTutorFinal.db')

c = conn.cursor()

c.execute("ALTER TABLE Part ADD studentID INTEGER;")


conn.commit()
conn.close()
