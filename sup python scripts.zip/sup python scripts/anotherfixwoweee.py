import sqlite3

conn = sqlite3.connect('TimmyTutorFinal.db')

c = conn.cursor()

c.execute("UPDATE Part SET StudentId = 1 WHERE PartID=1;")


conn.commit()
conn.close()
