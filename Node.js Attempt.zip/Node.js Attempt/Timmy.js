const sqlite3 = require('sqlite3').verbose();
var standard_input = process.stdin;
var overData = null;
standard_input.setEncoding('utf-8');
// open the database
let db = new sqlite3.Database('./TimmyTutorFinalDB.db', sqlite3.OPEN_READWRITE, (err) => {
  if (err) {
    console.error(err.message);
  }
  console.log('Connected to the Connected database.');
});
  console.log("Press");

while (manger = 0){
// When user input data and click enter key.
standard_input.on('data', function (data) {
    overData = data;
    console.log(overData);
    // User input exit.
    if(overData == '1'){
        // Program exit.
        console.log("User input complete, program exit.");
        process.exit();
    }else
    {
        // Print user input in console.
        console.log('User Input Data : ' + data);
    }
});

db.serialize(() => {
    db.each(`SELECT badgeID as id, badgeColour as name FROM Badges;`, (err, row) => {
      if (err) {
        console.error(err.message);
      }
      console.log(row.id + "\t" + row.name);
    });
  });
// close the database connection
db.close((err) => {
  if (err) {
    return console.error(err.message);
  }
  console.log('Close the database connection.');
});
}